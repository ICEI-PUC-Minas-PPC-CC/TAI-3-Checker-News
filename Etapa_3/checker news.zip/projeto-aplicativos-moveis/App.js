import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import HomeScreen from './src/paginas/HomeScreen';
import ResultScreen from './src/paginas/ResultScreen';
import HistoryScreen from './src/paginas/HistoryScreen';
import AboutScreen from './src/paginas/AboutScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return(
    <NavigationContainer>
      <Stack.Navigator
  screenOptions={{
    headerStyle: {
      backgroundColor: '#2563EB'
    },
    headerTintColor: '#FFF',
    headerTitleStyle: {
      fontWeight: 'bold'
    }
  }}
>
        <Stack.Screen
          name="Home"
          component={HomeScreen}
          options={{title: 'Verificador de Notícias'}}
        />
        <Stack.Screen
          name="Resultado"
          component={ResultScreen}
        />
        <Stack.Screen
          name="Histórico"
          component={HistoryScreen}
        />
        <Stack.Screen
          name="Sobre"
          component={AboutScreen}
        />
      </Stack.Navigator>
    </NavigationContainer>   
  );
}