import AsyncStorage from '@react-native-async-storage/async-storage';

const CHAVE = 'historico_pesquisas';

export async function salvarPesquisa(texto) {
  try {
    const historico = await obterHistorico();

    const novoItem = {
      texto,
      data: new Date().toISOString()
    };

    const novoHistorico = [
      novoItem,
      ...historico.filter(item => item.texto !== texto)
    ];

    await AsyncStorage.setItem(
      CHAVE,
      JSON.stringify(novoHistorico.slice(0, 20))
    );
  } catch (error) {
    console.error(error);
  }
}

export async function obterHistorico() {
  try {
    const dados = await AsyncStorage.getItem(CHAVE);

    return dados ? JSON.parse(dados) : [];
  } catch (error) {
    console.error(error);
    return [];
  }
}

export async function limparHistorico() {
  try {
    await AsyncStorage.removeItem(CHAVE);
  } catch (error) {
    console.error(error);
  }
}

export async function removerPesquisa(texto) {
  try {
    const historico = await obterHistorico();

    const novoHistorico = historico.filter(
      item => item.texto !== texto
    );

    await AsyncStorage.setItem(
      CHAVE,
      JSON.stringify(novoHistorico)
    );
  } catch (error) {
    console.error(error);
  }
}