/*export async function buscarNoticias(termo) {
  try {
    const response = await fetch(
      `https://gnews.io/api/v4/search?q=${encodeURIComponent(
        termo
      )}&lang=pt&country=br&apikey=4b68d05ffd602b9f102c053537e7d359`
    );

    const data = await response.json();

    console.log(data);

  console.log(data);
  console.log(data.articles);

    return data.articles || [];
  } catch (error) {
    console.error(error);
    return [];
  }
}*/

export async function buscarNoticias(termo) {
  try {
    const url1 =
      `https://gnews.io/api/v4/search?q=${encodeURIComponent(
        termo
      )}&lang=pt&country=br&page=1&apikey=4b68d05ffd602b9f102c053537e7d359`;

    const url2 =
      `https://gnews.io/api/v4/search?q=${encodeURIComponent(
        termo
      )}&lang=pt&country=br&page=2&apikey=4b68d05ffd602b9f102c053537e7d359`;

    const [res1, res2] = await Promise.all([
      fetch(url1),
      fetch(url2)
    ]);

    const data1 = await res1.json();
    const data2 = await res2.json();

    const artigos = [
      ...(data1.articles || []),
      ...(data2.articles || [])
    ];

    const artigosUnicos = artigos.filter(
      (artigo, index, self) =>
        index === self.findIndex(
          a => a.url === artigo.url
        )
    );

    console.log(
      `Encontrados: ${artigosUnicos.length}`
    );

    return artigosUnicos;
  } catch (error) {
    console.error(error);
    return [];
  }
}