import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function AboutScreen() {
  return (
    <View style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.icone}>
          📰
        </Text>

        <Text style={styles.titulo}>
          Verificador de Notícias
        </Text>

        <Text style={styles.texto}>
          Aplicativo desenvolvido em React Native
          utilizando Expo e a API GNews.
        </Text>

        <Text style={styles.texto}>
          Seu objetivo é auxiliar usuários na
          verificação de informações por meio da
          comparação com diversas fontes
          jornalísticas.
        </Text>

        <Text style={styles.rodape}>
          Versão 1.0.0
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#F5F7FA'
  },

  card: {
    backgroundColor: '#FFF',
    borderRadius: 20,
    padding: 25,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4
  },

  icone: {
    fontSize: 50,
    textAlign: 'center',
    marginBottom: 15
  },

  titulo: {
    fontSize: 26,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    color: '#1E293B'
  },

  texto: {
    fontSize: 16,
    lineHeight: 24,
    marginBottom: 15,
    textAlign: 'center',
    color: '#475569'
  },

  rodape: {
    textAlign: 'center',
    marginTop: 20,
    color: '#94A3B8',
    fontSize: 14
  }
});