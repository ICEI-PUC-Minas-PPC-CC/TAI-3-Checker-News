import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet
} from 'react-native';
import SearchBar from '../../src/componentes/SearchBar';
import { salvarPesquisa } from '../servicos/history';

export default function HomeScreen({ navigation }) {
  const [texto, setTexto] = useState('');

  const verificarNoticia = async () => {
    if (!texto.trim()) {
      alert('Digite um assunto para pesquisar');
      return;
    }

    await salvarPesquisa(texto);
    
    navigation.navigate('Resultado', {
      noticia: texto
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        Verificador de Notícias
      </Text>

      <SearchBar
        texto={texto}
        setTexto={setTexto}
        onPesquisar={verificarNoticia}
      />

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navigation.navigate('Histórico')}
      >
        <Text style={styles.textoBotao}>
          Ver Histórico
        </Text>
      </TouchableOpacity>

      <TouchableOpacity
        style={styles.botaoSecundario}
        onPress={() => navigation.navigate('Sobre')}
      >
        <Text style={styles.textoBotao}>
          Sobre
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
    justifyContent: 'center',
    backgroundColor: '#F5F7FA'
  },

  titulo: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 30,
    color: '#1E293B'
  },

  botaoSecundario: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 15,
    marginTop: 12,
    elevation: 2
  },

  textoBotao: {
    textAlign: 'center',
    fontSize: 16,
    fontWeight: '600',
    color: '#1E293B'
  }
});