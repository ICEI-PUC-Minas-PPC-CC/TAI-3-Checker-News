import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView} from 'react-native';
import { buscarNoticias } from '../servicos/newsApi.js'
import ResultCard from '../../src/componentes/ResultCard';

export default function ResultScreen({ route }) {
  const { noticia } = route.params;

  const [artigos, setArtigos] = useState([]);
  const [loading, setLoading] = useState(true);

  const fontesConfiaveis = [
    'CNN Brasil',
    'UOL Notícias',
    'O GLOBO',
    'Agência Brasil',
    'BBC News Brasil',
    'G1',
    'Folha de S.Paulo',
    'Estadão'
  ];

  useEffect(() => {
    async function carregar() {
      const resultado = await buscarNoticias(noticia);

      setArtigos(resultado);
      setLoading(false);
    }

    carregar();
  }, [noticia]);

  if (loading) {
    return (
      <View style={styles.container}>
       <Text>Pesquisando...</Text>
      </View>
    );
  }

  const fontesEncontradas = artigos.filter(
    artigo => fontesConfiaveis.includes(artigo.source?.name)
  ).length;

  let credibilidade = 'Baixa';

  if (fontesEncontradas >= 3) {
    credibilidade = 'Alta';
  } else if (fontesEncontradas >= 1) {
    credibilidade = 'Média';
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.titulo}>
        Resultado
      </Text>

      <Text style={styles.pesquisa}>
        {noticia}
      </Text>

      <Text style={styles.subtitulo}>
        Notícias encontradas: {artigos.length}
      </Text>

      <Text
  style={[
    styles.credibilidade,
    {
      color:
        credibilidade === 'Alta'
          ? '#22C55E'
          : credibilidade === 'Média'
          ? '#F59E0B'
          : '#EF4444'
    }
  ]}
>
  Credibilidade: {credibilidade}
</Text>

      <Text style={styles.fontesInfo}>
        Fontes confiáveis encontradas: {fontesEncontradas}
      </Text>

      {artigos.length === 0 ? (
        <View style={styles.semResultados}>
          <Text style={styles.textoSemResultados}>
            Nenhuma notícia encontrada.
          </Text>

          <Text style={styles.textoDica}>
            Tente pesquisar usando palavras-chave mais curtas ou gerais.
          </Text>
        </View>
      ) : (
        artigos.map((item, index) => (
          <ResultCard
            key={index}
            artigo={item}
          />
        ))
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
  flex: 1,
  padding: 20,
  backgroundColor: '#F5F7FA'
  },

  titulo: {
  fontSize: 30,
  fontWeight: 'bold',
  color: '#1E293B'
  },

  pesquisa: {
    marginVertical: 15
  },

  subtitulo: {
    fontSize: 18,
    marginBottom: 20
  },

  credibilidade: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 20
  },

  fontesInfo: {
    marginBottom: 20
  },

  semResultados: {
    marginTop: 20,
    alignItems: 'center'
  },

  textoSemResultados: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10
  },

  textoDica: {
    textAlign: 'center',
    color: '#666'
  }
});