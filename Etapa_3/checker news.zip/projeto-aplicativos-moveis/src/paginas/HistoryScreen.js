import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Alert } from 'react-native';
import { obterHistorico, limparHistorico, removerPesquisa } from '../servicos/history';

export default function HistoryScreen({ navigation }) {
  const [historico, setHistorico] = useState([]);

  useEffect(() => {
    carregarHistorico();
  }, []);

  async function carregarHistorico() {
    const dados = await obterHistorico();
    setHistorico(dados);
  }

  async function handleLimparHistorico() {
    Alert.alert(
      'Limpar histórico',
      'Tem certeza que deseja limpar todo o histórico?',
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Limpar',
          style: 'destructive',
          onPress: async () => {
            await limparHistorico();
            carregarHistorico();
          }
        }
      ]
    );
  }

  async function handleRemoverPesquisa(texto) {
    await removerPesquisa(texto);
    const dados = await obterHistorico();
    setHistorico(dados);
  }

  function confirmarExclusao(item) {
    Alert.alert(
      'Excluir pesquisa',
      `Deseja excluir a pesquisa "${item.texto}"?`,
      [
        {
          text: 'Cancelar',
          style: 'cancel'
        },
        {
          text: 'Excluir',
          style: 'destructive',
          onPress: () => handleRemoverPesquisa(item.texto)
        }
      ]
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.titulo}>
        Histórico
      </Text>

      {historico.length === 0 ? (
        <Text style={styles.textoVazio}>
          Nenhuma pesquisa realizada.
        </Text>
      ) : (
        <>
          <TouchableOpacity
            style={styles.botaoLimpar}
            onPress={handleLimparHistorico}
          >
            <Text style={styles.textoBotao}>Limpar Histórico</Text>
          </TouchableOpacity>

          <FlatList
            data={historico}
            keyExtractor={(item, index) => index.toString()}
            renderItem={({ item }) => (
              <View style={styles.item}>
                <TouchableOpacity
                  style={styles.areaPesquisa}
                  onPress={() => confirmarExclusao(item)}
                >
                  <Text style={styles.textoPesquisa}>
                    {item.texto}
                  </Text>

                  <Text style={styles.data}>
                    {new Date(item.data).toLocaleString('pt-BR')}
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.botaoExcluir}
                  onPress={() => confirmarExclusao(item)}
                >
                  <Text style={styles.textoExcluir}>
                    ×
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          />
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#F5F7FA'
  },

  titulo: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20
  },

  textoVazio: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 50
  },

  botaoLimpar: {
    backgroundColor: '#f44336',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20
  },

  textoBotao: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold'
  },

  textoPesquisa: {
    fontSize: 16,
    fontWeight: 'bold'
  },

  data: {
    marginTop: 5,
    color: '#666',
    fontSize: 12
  },

  item: {
  flexDirection: 'row',
  alignItems: 'center',
  backgroundColor: '#FFF',
  borderRadius: 15,
  marginBottom: 12,
  elevation: 2
},

  areaPesquisa: {
    flex: 1,
    padding: 15
  },

  botaoExcluir: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#F5F7FA',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10
  },

  textoExcluir: {
    color: '#666',
    fontSize: 20,
    fontWeight: 'bold'
  }
});