import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Linking,
  TouchableOpacity
} from 'react-native';

export default function ResultCard({ artigo }) {
  return (
    <View style={styles.card}>
      <Text style={styles.titulo}>
        {artigo.title}
      </Text>

      <Text>
        Fonte: {artigo.source?.name}
      </Text>

      <Text>
        Data: {new Date(artigo.publishedAt).toLocaleDateString('pt-BR')}
      </Text>

      <TouchableOpacity
        onPress={() => Linking.openURL(artigo.url)}
      >
        <Text style={styles.link}>
          Ler notícia
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 15,
    marginBottom: 12,
    elevation: 3
  },

  titulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1E293B',
    marginBottom: 8
  },

  link: {
    color: '#2563EB',
    marginTop: 10,
    fontWeight: 'bold'
  }
});