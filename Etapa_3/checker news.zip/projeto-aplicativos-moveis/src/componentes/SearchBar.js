import React from 'react';
import {
  View,
  TextInput,
  TouchableOpacity,
  Text,
  StyleSheet
} from 'react-native';

export default function SearchBar({
  texto,
  setTexto,
  onPesquisar
}) {
  return (
    <View>
      <TextInput
        style={styles.input}
        placeholder="Digite uma notícia ou assunto"
        value={texto}
        onChangeText={setTexto}
      />

      <TouchableOpacity
        style={styles.botao}
        onPress={onPesquisar}
      >
        <Text style={styles.textoBotao}>
          Verificar
        </Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  input: {
    backgroundColor: '#FFF',
    borderRadius: 15,
    padding: 16,
    marginBottom: 15,
    elevation: 2
  },

  botao: {
    backgroundColor: '#2563EB',
    padding: 16,
    borderRadius: 15,
    elevation: 3
  },

  textoBotao: {
    color: '#FFF',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16
  }
});